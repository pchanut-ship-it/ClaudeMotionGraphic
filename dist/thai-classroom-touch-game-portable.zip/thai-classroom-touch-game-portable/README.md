# Thai classroom touch game: portable skill package

Theme, visual design and UX/UI rules for building classroom touch games in
the style of **วันหนึ่งที่ตลาด**, packaged so they can be used with Claude
and with other AI assistants.

## สรุปภาษาไทย

แพ็กเกจนี้มีสกิลเดียวกันในหลายรูปแบบ เลือกใช้ตามแพลตฟอร์ม:

| ใช้กับ | ใช้ไฟล์ |
|---|---|
| Claude (claude.ai, Claude Desktop, Claude Code) | `claude/thai-classroom-touch-game.skill` หรือโฟลเดอร์ `skill/thai-classroom-touch-game/` |
| เครื่องมือ AI อื่นที่รองรับสกิลแบบโฟลเดอร์ SKILL.md | โฟลเดอร์ `skill/thai-classroom-touch-game/` |
| ChatGPT (Custom GPT หรือ Project), Gemini (Gem), Copilot และแชตบอตอื่น ๆ | วาง `chat-assistants/INSTRUCTIONS-SHORT.md` ในช่องคำสั่ง และอัปโหลด `INSTRUCTIONS-FULL.md` กับ `game-template.txt` เป็นไฟล์ความรู้ |
| ผู้ช่วยเขียนโค้ด (Cursor, Windsurf, GitHub Copilot, Codex, Gemini CLI ฯลฯ) | วาง `coding-agents/AGENTS.md` และโฟลเดอร์ `thai-classroom-touch-game/` ไว้ที่ราก (root) ของโปรเจกต์ |

---

## What's inside

```
thai-classroom-touch-game-portable/
├── README.md                         this file
├── skill/thai-classroom-touch-game/  the skill in the open SKILL.md folder format
│   ├── SKILL.md                      main instructions (YAML front matter + Markdown)
│   ├── references/                   visual design, UX patterns, Thai text, TV compatibility, template map
│   ├── assets/game-template.html     the finished game, used as the starting template
│   └── scripts/                      checks: static (Python), layout audit and play-through (Node + Playwright)
├── claude/
│   └── thai-classroom-touch-game.skill   ready-to-upload Claude skill
├── chat-assistants/
│   ├── INSTRUCTIONS-SHORT.md         under 8,000 characters, for an assistant's instruction box
│   ├── INSTRUCTIONS-FULL.md          everything in one Markdown file (SKILL.md + all references)
│   ├── game-template.html            the template game
│   └── game-template.txt             the same file as plain text, for uploaders that refuse .html
└── coding-agents/
    └── AGENTS.md                     project instructions for coding agents
```

## How to use it

### Claude
- **claude.ai or Claude Desktop**: upload `claude/thai-classroom-touch-game.skill`
  in the Skills settings, or use the Save skill button when the file is shared
  in a chat.
- **Claude Code**: copy `skill/thai-classroom-touch-game/` into a project's
  `.claude/skills/` folder, or into `~/.claude/skills/` for all projects.

### Other tools that read SKILL.md skill folders
The `skill/thai-classroom-touch-game/` folder follows the open SKILL.md
format: a folder with a `SKILL.md` (name and description in YAML front
matter) plus `references/`, `assets/` and `scripts/`. Copy it into the
skills folder your tool uses (see that tool's documentation for the
location).

### ChatGPT, Gemini, Copilot and other chat assistants
1. Create a custom assistant (a custom GPT, a ChatGPT Project, a Gemini Gem,
   or similar).
2. Paste the contents of `chat-assistants/INSTRUCTIONS-SHORT.md` into its
   instructions. It stays under 8,000 characters, so it fits a custom GPT's
   instruction box.
3. Upload as knowledge files: `INSTRUCTIONS-FULL.md` and `game-template.txt`
   (or `game-template.html` if HTML uploads are accepted).
4. Ask, for example: "สร้างเกมฝึกสระเอือ ป.2 แบบวันหนึ่งที่ตลาด มี 2 ด่าน".

If the assistant has no instruction box or file upload, start a new chat by
pasting `INSTRUCTIONS-FULL.md`, then attach `game-template.txt` with your
request.

Chat assistants usually can't run the bundled checks (they need a browser
engine). The instructions tell the model to review the code against the
rules instead, so test the finished HTML on the classroom TV yourself.

### Coding agents (Cursor, Windsurf, GitHub Copilot, OpenAI Codex, Gemini CLI, …)
1. Put `coding-agents/AGENTS.md` in the root of your project.
2. Copy `skill/thai-classroom-touch-game/` into the same root, so that the
   paths in AGENTS.md (`thai-classroom-touch-game/assets/…`,
   `…/references/…`, `…/scripts/…`) resolve.
3. If your tool reads a different instruction file instead of AGENTS.md
   (for example `.github/copilot-instructions.md`, `GEMINI.md`, `CLAUDE.md`
   or a rule file under `.cursor/rules/`), copy the same content into that
   file.

### Running the checks (any platform that can run code)
Requires Python 3, Node.js and Playwright (`npm i -D playwright && npx playwright install chromium`).
```bash
python3 thai-classroom-touch-game/scripts/check_static.py path/to/game.html
node thai-classroom-touch-game/scripts/check_layout.js path/to/game.html --out layout-check
node thai-classroom-touch-game/scripts/playthrough_example.js thai-classroom-touch-game/assets/game-template.html --mode touch
```
`check_static.py` also parses the script as strict ES5 if `acorn` is
installed (`npm i -g acorn`).

## Keeping versions in sync
`skill/` is the source. `INSTRUCTIONS-FULL.md` and `AGENTS.md` are generated
from it, and `INSTRUCTIONS-SHORT.md` is a hand-written summary. When you
change the skill, regenerate the package, or edit all three files.
