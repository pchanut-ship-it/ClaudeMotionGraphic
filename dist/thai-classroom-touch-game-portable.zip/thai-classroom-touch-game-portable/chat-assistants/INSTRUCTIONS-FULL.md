# Thai classroom touch game: complete instructions (single-file edition)

> **How to read this file.** It merges the skill's `SKILL.md` and its five reference files.
> Where the text says `references/<name>.md`, see the section **Reference: <name>** further down.
> `assets/game-template.html` is the separate file `game-template.html` (also shipped as `game-template.txt`).
> The `scripts/` checks are in the package folder `skill/thai-classroom-touch-game/scripts/`
> and need Python 3, Node.js and Playwright. If you cannot run code, review against the rules instead.

## When to use

Design and build touch-screen learning games for Thai primary classrooms that run on a big smart TV or interactive board at the front of the room, in the house style of the game วันหนึ่งที่ตลาด - a bright Thai fresh-market world (striped awning, wooden signs, woven frames, mango yellow), Mali font, big pressable tiles, answers by tap or drag, icon-plus-text feedback, two-step hints, an animated demo hand, a cover page, synthesized sound effects and a teacher summary, shipped as one self-contained ES5 HTML file. Use this whenever someone wants an educational or classroom game, เกมการศึกษา, เกมสอนภาษาไทย, เกมฝึกอ่านหรือสะกดคำ, a game for อักษรนำ, สระ, วรรณยุกต์, มาตราตัวสะกด, คำควบกล้ำ or vocabulary, a touch game for a smart TV or smart board for young learners, or a new shop, level or mechanic for วันหนึ่งที่ตลาด, even if they never name this style or skill.

## Thai classroom touch game (วันหนึ่งที่ตลาด house style)

This skill packages a game that was built, tested and refined for a real Thai
classroom: Grade 1–3 students take turns at a large touch TV while the whole
class watches. It records the theme, the visual system, the UX rules and the
mistakes that cost time, so the next game of this kind starts where the last
one finished.

The working implementation is `assets/game-template.html` (about 1,900 lines,
Thai comments). **Start every new game from a copy of it** rather than from a
blank file. Its touch system, text fitting, sound, effects, stats and teacher
summary already handle the hard cases: imprecise touch panels, resting palms,
old Smart-TV browsers, Thai combining marks and screens that are not 16:9.

### Who the game is for (the reason behind every rule)

- **One child at a time, standing at a tall screen.** Young children cannot
  reach the top of a 75" TV, so everything they press lives in the lower 60%.
- **The whole class watches from up to ~6 m.** Text is huge, feedback is
  readable from the back row, and an answer stays on screen until someone
  presses ไปต่อ, because the class reads it together.
- **Large touch panels are imprecise.** Fingers slip, palms rest on the glass,
  and two children touch at once. Taps must forgive movement, drop zones must
  be generous, and a new touch replaces a stuck one.
- **Early readers.** Short, simple Thai, pictures for every word, and icons
  next to every message. Colour is never the only signal.
- **The teacher runs it.** One file, no install, works offline apart from the
  font. The teacher needs fullscreen, home, a sound switch and a results page,
  all small in the top-right corner, out of children's reach.
- **Old TV browsers.** ES5 JavaScript and conservative CSS. Every browser
  feature that might be missing is guarded.

### Workflow

1. **Pin down the brief.** You need the target skill (e.g. อักษรนำ, สระเอือ),
   the word list with reading guides, the grade, the mechanics per level,
   and whether sound is wanted. Ask only for what is missing. Defaults: Grade
   1–3, 2 shops (levels), 5 questions in a letter or word level, synthesized
   sound with a teacher on/off switch, market theme.
2. **Copy the template** into the project (e.g. `<game>/index.html`). Read
   `references/template-map.md` before editing: it says which sections are
   engine (keep as is), which are content (replace) and which are screens
   (adapt), and lists the helper functions to reuse.
3. **Content first.** Put every word, sentence and story page in the editable
   arrays at the top of the script (`WORDS`, `STORY`, or new arrays shaped the
   same way), with Thai comments on each field so a teacher can edit them
   later. Validate the data in code (for example, a blank pattern plus its
   answer must rebuild the word) and skip bad rows instead of crashing.
4. **One shop per mechanic.** Each level is an entry in `SHOPS` with an icon,
   a name, a skill label, a reward item, a demo and a `start()` function. The
   map renders whatever is in `SHOPS`, so new mechanics slot in as new shops.
   Recipes for the screens are in `references/ux-patterns.md`.
5. **Keep the visual system.** Use the tokens, textures, components and
   motion in `references/visual-design.md`. A new topic can have its own stall
   colours, goods and scene emoji, but keep the awning, wood, woven frames,
   pressable cards and type scale so all games feel like one series.
6. **Get the Thai right** wherever a blank touches a word, and wherever
   multi-line Thai text has stacked marks. Read `references/thai-text.md`.
7. **Respect the device.** Read `references/tv-compat.md` before adding any
   new JS or CSS feature.
8. **Verify** (next section), look at the screenshots yourself, fix, re-run.
9. **Deliver** the file, screenshots and a short report (last section).

### Non-negotiables

| Rule | Why |
|---|---|
| Child controls start at or below 40% of the stage height. Above that: pictures, sentences, status only. Teacher buttons sit small in the top-right corner. | Children are short. The top area belongs to what the class reads. |
| Every answer works by **tap** and by **drag**. A tap fills the active blank, a drag drops on any blank. Movement under 10 px counts as a tap. | Some children drag, some tap, and panels jitter. Neither path may fail. |
| Sizes use stage units (1u = 1% of stage height): target words ≥ 10u, sentences ≥ 6u, tiles and buttons ≥ 12u tall. | Readable at ~6 m on a 1080p TV, and pressable with a child's finger. |
| Feedback is always an icon + short text + colour (✔ correct, ↺ try again, 💡 hint), with the icons drawn as inline SVG. | Colour-blind children and the back row both need it. SVG icons render on every TV, while symbol glyphs may not. |
| A correct answer stays on screen, with its reading guide, until the child presses **ไปต่อ ▶**. No auto-advance and no timers. | The teacher pauses here for the class to read aloud. |
| Wrong answers are gentle: the piece slides back, shakes, and (when only one answer is possible) dims with a ✖ badge, plus ↺ and a short hint. | Mistakes are part of learning in front of peers, so nothing loud or shaming. |
| Two-step hints: step 1 points at the right place or rule, step 2 removes a wrong choice. Hint use is recorded. | Children should still do the last step themselves, and the teacher learns who needed help. |
| One self-contained HTML file. The only external resource is the Google Font **Mali**. Pictures are emoji or CSS/SVG. | Classroom wifi is unreliable and teachers copy the file around. |
| ES5 script, conservative CSS, guarded `localStorage`; the game must run fully without storage, audio or Pointer Events. | Smart-TV browsers are old and locked down. |
| The play area is exactly 16:9 and fills any screen: background and awning extend sideways, a wooden counter fills extra height, and portrait screens show a rotate hint. | A browser that isn't fullscreen should still look finished, without brown letterbox bars. |
| `prefers-reduced-motion` turns effects off (`transition: none`, 1 ms animations). | Some children get motion sickness or are distracted easily. |
| Teacher summary by skill: first-try results, which items used which hint step, and words to review (with reading guide). Never a single total score. Reset needs two taps. | The teacher plans the next lesson from it. |

### The look in brief

A Thai fresh market at mid-morning: an orange and cream scalloped awning
across the top, a warm mango-yellow woven background, dark-brown ink on cream
paper, wooden sign frames with nail heads, woven bamboo picture frames, and
big rounded "pressable" cards with a solid bottom shadow that sinks when
touched. The font is **Mali** (looped Thai letters, friendly for early
readers). The answer colour is burnt orange (`#b23c06` on `#fff0c2`). Word
cards all share one light blue, so children read the word instead of matching
colours. Full tokens, CSS snippets and the motion catalogue are in
`references/visual-design.md`.

### Screen flow

cover (เริ่มเล่น) → market map (shops, basket, stamps, teacher summary button)
→ demo (cartoon hand drags a piece, then เริ่มเลย) → level questions → finish
screen (recap, reward, confetti) → back to the map, where the reward flies
into the basket and the shop gets a "ผ่านแล้ว ✔" stamp. Story-type games end
on a read-aloud page with the note "ครูให้นักเรียนอ่านออกเสียงพร้อมกัน",
because the game cannot check pronunciation.

### Verify before delivering

If your environment can run code (Python 3, Node.js and Playwright), run the bundled
checks (paths are relative to this skill's folder). If it can't, review the code against
the non-negotiables and `references/tv-compat.md` by reading it, and say so in the report.

```bash
python3 scripts/check_static.py <game>/index.html   # forbidden syntax, external hosts, ES5 parse
node scripts/check_layout.js <game>/index.html --out <scratch>/layout   # positions, sizes, errors, 5 screen shapes, 4 degraded modes
```

`check_layout.js` needs Playwright. It audits the cover and the map only,
because it can't know your game's answers. For the levels, write a
play-through modelled on `scripts/playthrough_example.js`. That example plays
the whole template game with mouse taps, drags and touch, waits for
`#nextWrap.show` instead of fixed sleeps, and saves screenshots. Then **look at
the screenshots**. Clipped Thai marks, overlaps and fit problems show up there,
not in the numbers.

Measure positions and sizes only after entrance animations settle (about
1 s). Mid-animation transforms report false failures. When several browsers
run in parallel the machine slows down, so rerun a single failed scenario on
its own before calling it a bug.

### Lessons from the first build

Each of these cost a debugging round. Avoid them up front:

- **Class names collide in one big file.** `.story` was both the demo text
  and the story container, and the demo text vanished. Prefix screen-specific
  classes (`.demo-story`, `.cover-title`).
- **`overflow:hidden` on a text line clips Thai marks**, both the lower vowels
  (ู in หมู) and stacked tone marks (เสื้อ). Use line-height ≥ 1.42 for a
  single line and ≥ 1.6 for multi-line Thai, and add padding instead of
  clipping.
- **Write reduced-motion CSS as `transition: none !important`.** Never write
  `transition-duration: 1ms`: the default property is `all`, so font sizes
  would transition too and every synchronous measurement goes wrong.
- **Text-fit loops must freeze motion while measuring.** The template's
  `fitText` disables transitions and adds `.fitting` (`animation: none` on
  descendants), because entrance transforms with `backwards` fill count as
  overflow.
- **Animations override transforms.** The animation listed later in the CSS
  wins. Define entrance and idle classes *before* `.shake` and `.removed`. Use
  fill-mode `backwards`, never `both` or `forwards`, on anything pressable.
  Use two-class selectors for state animations (`.blank.shake` after
  `.blank.active`).
- **Guard the answer moment.** ไปต่อ appears about 0.45 s after a correct
  answer with a 0.3 s tap lock, so a child hammering the screen cannot skip
  the reading. Tests must wait for `#nextWrap.show`.
- **Keep remaining pieces still.** Hide used cards with `visibility:hidden`
  so the rest do not slide under a child's finger.
- **A new touch cancels the old gesture**, so a palm resting on the glass
  never blocks the next tap.
- **Audio starts only after a gesture.** Create or resume the AudioContext in
  the first `pointerdown`. The cover's เริ่มเล่น button provides that tap.
- **Letterbox bars read as "not full screen".** Paint the background on
  `body`, repeat the awning tile across the full width, pin the stage to the
  top, and put a wooden counter underneath.
- **Hint text must be true for every word it is shown with.**
  "ตัวอักษรนี้นำหน้า แต่ไม่ออกเสียง" is wrong for ขนม and ตลาด, where the
  first letter is pronounced (ขะ, ตะ). Write tips per group, with optional
  per-word overrides.
- **Captions and pictures can give the answer away** (the caption หยวกกล้วย
  under the question _ยวก). Point such cases out to the user instead of
  silently changing the brief.
- **Fitting a whole story on one screen** can push text slightly below the
  6u target. Report the number rather than hiding it.

### Deliver

- Save the game in the project, commit it, and send the HTML file plus a
  handful of screenshots (cover, a correct answer, a finished page, the
  teacher summary).
- Report against the non-negotiables: what passed, any number that fell short
  and why, and every decision you made that the brief did not specify.
- If the user wants a shareable preview and your platform hosts HTML pages
  (for example Claude Artifacts), follow `references/tv-compat.md` §7. Some
  hosts add their own page skeleton, so the game's `<!DOCTYPE>`, `<html>`,
  `<head>` and `<body>` tags must be stripped first.
- Answer in the user's language, which is often Thai. In-game copy is short,
  simple Thai for the grade level. Teacher-facing text may be more formal.


---

# Reference: visual-design

## Visual design system: the Thai fresh market

Everything below is already implemented in `assets/game-template.html`. Use
this file to understand the system, and to stay consistent when you add new
screens or a new shop.

### Contents
1. Stage and units
2. Layout zones
3. Colour tokens
4. Typography
5. Textures (awning, bunting, wood, woven, basket, floor, background)
6. Components
7. Icons and emoji
8. Motion catalogue
9. Cover page composition
10. Giving a new game its own flavour

---

### 1. Stage and units

The play area is a 16:9 stage. Every size is written in stage units:
`--u` = 1% of the stage height, so `calc(var(--u)*12)` is 12% of the height.
This replaces vh and makes the layout identical on every screen.

```css
:root{ --u:1vh; }
@media (max-aspect-ratio:16/9){ :root{ --u:0.5625vw; } }   /* narrower than 16:9 → width decides */
#app{ position:absolute; left:50%; top:0;                    /* pinned to the top */
      width:calc(var(--u)*177.78); height:calc(var(--u)*100);
      margin-left:calc(var(--u)*-88.89); overflow:hidden; }
```

- Do not centre the stage with `transform: translate(-50%,-50%)`. A transform
  turns `#app` into the containing block for `position:fixed` drag clones.
  Use negative margins instead.
- The market background is painted on `body`, so the whole screen is
  textured. The awning is a body-level strip that repeats a 14.8u tile
  across the full width, aligned with
  `background-position: calc(50vw - var(--u)*88.89) 0`. A `.floor` element
  (wood planks) fills from `top: calc(var(--u)*100)` to the bottom, so it is
  zero-height on 16:9 or wider screens. In portrait it shows "หมุนจอเป็น
  แนวนอน".
- The effects layer `#fx` is `position:fixed` over the whole viewport, so
  confetti also falls beside the stage.

### 2. Layout zones (stage units, top to bottom)

| Zone | Top–height | Holds | Touchable? |
|---|---|---|---|
| Awning | 0–9.6 | stripes, status pill (top-left), teacher buttons (top-right) | teacher only |
| zA | 10.5–38.5 | picture, scene frame, shopkeeper bubble, progress | no |
| zB | 40–67 | the sign with the slot, or the sentence box with blanks | blanks only (≥ 40) |
| zC | 68–77.5 | feedback pill | no |
| zD | 79–98.5 | hint button (left), tiles or word cards (centre), ไปต่อ (centre, replaces the pieces) | yes |

The map, cover, finish and summary screens use their own positions but keep
the same principle: everything a child presses starts at ≥ 40u.

### 3. Colour tokens

| Token | Hex | Use |
|---|---|---|
| mango | `#ffc83d` (glow `#ffe48f`) | page background with diagonal woven stripes |
| ink | `#2b1a0c` | all text, borders, button shadows |
| paper | `#fffaf0` | sign faces, pills, tiles, cards behind text |
| sentence paper | `#fffdf6` | sentence box, book page, summary panels |
| answer (hi) | `#b23c06` on `#fff0c2` | filled letters and words, highlighted words in the story |
| wood | `#8a5426`, dark `#5c3714`, frame gradient `#d39556 → #a9672f` | frames, borders, shadows |
| awning orange / cream | `#ef661c` / `#fff4dc` | top awning, shop 1, stall A |
| awning green | `#2f8f4e` / `#eafbe9` | shop 2, stall B |
| awning blue | `#2b62a8` / `#e6f0ff` | stall C, cover badge |
| word card | `#dcebff`, border and shadow `#1d4478` | **every** word card in one colour |
| active blank | border `#1d4478`, fill `#e6f0ff`, a "?" mark | the blank a tap will fill |
| correct | text `#14532a` on `#d4f4da` | ✔ feedback, ok chips |
| try again | text `#7a2e05` on `#ffe4cf` | ↺ feedback, review chips |
| hint | text `#574100` on `#fff4b0`; clue highlight `#fff07a` + underline `#9a6b00` | 💡 feedback, clue word |
| go button | `#8fe39a` | เริ่มเล่น, เริ่มเลย, ไปต่อ, กลับแผนที่ |
| hint button | `#ffe36e` | 💡 คำใบ้ |
| stamp | `#a3201a` | "ผ่านแล้ว ✔" ink stamp |
| confetti | `#ef661c #ffc21a #2f9e44 #3b82d6 #e8456b #9b59d0` | bursts, confetti, bunting |

Text is always dark on light. White text appears only on the blue cover
badge and the green ✔ circle.

### 4. Typography

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Mali:wght@400;600;700&display=swap">
```
`font-family: 'Mali','Itim','Leelawadee UI','Leelawadee','Thonburi','Noto Sans Thai','Sarabun','Tahoma',sans-serif;`

Mali has looped Thai letters, which early readers recognise from school
books. Fallbacks keep the layout working offline (the template was checked
with a fallback font).

Type scale in stage units (bold 700 unless noted):

| Element | Size |
|---|---|
| cover title | 12.6 |
| sign word (missing-letter task) | 12.5 (fit down to 7 for long words) |
| letter tile glyph | 11 |
| title on the map board | 8.6 |
| ไปต่อ / เริ่มเลย | 7–7.5 |
| sentence (cloze) | 6.8, fit down to 5 only for teacher-added long text |
| word card | 6.4 (fit down to 4.4 so the row stays on one line) |
| shop name | 6.4 |
| story page (whole story) | fit from 6.4 (lands near 5.6) |
| feedback pill | 4.7 (fit down to 3.4) |
| hint button | 4.8 |
| subtitles, bubbles | 3.6–4.8 (600) |
| status pill | 3.4 |
| teacher buttons | 2.7 |
| summary panels | 3.4, fit down to 2.2 |

Line-heights: single-line Thai ≥ 1.42, sentences 1.95 (room for blank
boxes), multi-line reading text 1.62, cards and tiles use fixed `line-height`
in u.

### 5. Textures

**Awning tile** (one orange and one cream stripe, scalloped; repeat-x, 14.8u × 9.6u):
```js
function awningTile() {
  var d1 = 'M0 8H74V48A37 37 0 0 1 0 48Z', d2 = 'M74 8H148V48A37 37 0 0 1 74 48Z';
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 148 96" preserveAspectRatio="none">' +
    '<g fill="rgba(70,30,0,.18)" transform="translate(0 5)"><path d="' + d1 + '"/><path d="' + d2 + '"/></g>' +
    '<path d="' + d1 + '" fill="#ef661c"/><path d="' + d2 + '" fill="#fff4dc"/>' +
    '<rect x="0" y="0" width="148" height="10" fill="#7a4a1f"/></svg>';
  return 'url("data:image/svg+xml,' + encodeURIComponent(svg) + '")';
}
```

**Background**: mango base, two 45° repeating stripes (white 16% and brown
10%, 1.1u on 4.4u), plus a radial glow at 50% 40%.

**Wood frame**: `.wood-frame` has 1.2u padding, a vertical gradient
`#d39556 → #a9672f`, faint horizontal grain, a 1u bottom shadow in
`#5c3714`, and two nail heads drawn by `:before/:after`. Inside it sits a
`.sign-face` (paper, inset border `#e3c393`), where the text goes.

**Woven frame** (pictures and scenes): `.woven` crosses two 45° repeating
gradients over `#d6a253`, with a 0.9u bottom shadow.

**Basket**: woven body with a large bottom radius, an arc handle (border
without bottom), and reward items placed *between* handle and body so they
peek out. A label pill on the front shows the count, or the reward message.

**Bunting** (cover): a string line plus inline-block CSS triangles in the
confetti colours.

**Floor**: horizontal plank lines over `#c98a4b → #9a5c2a` with a dark
`#6b3e19` top edge.

### 6. Components

**Pressable button `.btn`**: 0.5u ink border, 3u radius, white or a colour
fill, `box-shadow: 0 1.2u 0 ink`. In the `.pressed` state (added on
pointerdown, which is more reliable than `:active` on TVs) it gets
`translateY(1u)` and the shadow shrinks to 0.2u. `.off` means disabled: 40%
opacity, already pressed down. Variants: `.btn-go` (green),
`.btn-next` (15.5u tall, 7u text), `.btn-hint` (25u × 15u, yellow, with a count
badge circle in the top-right corner), `.btn-start` (16u), `.btn-teach`
(paper colour, 12u).

**Letter tile `.tile`**: 16.5u square, paper fill, ink border, brown bottom
shadow, glyph 11u. States: `.ghost` (left behind while dragging), `.dim`
(wrong: 35% opacity plus a ✖ badge), `.removed` (taken away by a hint: pops
out), `.gone` (used: `visibility:hidden`, so the space stays).

**Word card `.card`**: 14u tall, padding 0.5em, one colour for all
(`#dcebff` and `#1d4478`), font size inherited from the `.bank` row so the
row can be fitted as a whole.

**Slot `.slot`** (missing letter inside a word): an inline-block with a
dashed wood border, white fill and an invisible placeholder "ก" that sets
width and baseline. `.filled` switches to a solid answer-colour border, the
`#fff0c2` fill and the visible letter. `.hinted` adds a yellow ring that
pulses 3 times. `.drop-hover` turns it light blue while something is dragged
over it.

**Blank `.blank`** (whole word inside a sentence): an inline-block with a
uniform min-width of 3.1em, so its length gives no clue. Empty means a
dashed border. `.active` means a solid blue border, a "?" mark and a soft
glow pulse. `.filled` shows the word in the answer colour. The clue word for
a hint is a `.clue` span; `.clue.on` gives it a yellow highlight and an
underline.

**Feedback pill `.fb`** in zone C: one line, 4.7u, icon first.
`.fb-ok` / `.fb-re` / `.fb-tip`. It pops in on every new message.

**Big check**: a 13u green circle with a white SVG check, overlapping the
top-right corner of the sign. It spins and pops in on a correct answer.

**Status pill** (top-left, on the awning): shop icon, name, "ป้ายที่ 2 / 5".
Max width 112u, so it never meets the teacher buttons.

**Teacher buttons** (top-right, 5.4u tall): 🔊 เสียง: เปิด/ปิด, หน้าแรก
(hidden on the cover and the map), เต็มจอ (hidden when the Fullscreen API is
missing).

**Shop card** (map): 62u × 41.5u paper card with a striped mini awning in the
shop's colour, a 13u bobbing emoji, the name, "ด่าน n · skill", a round stop
number at the top-left, and a rotated red ink stamp "ผ่านแล้ว ✔" once
finished.

**Progress boards** (Level 1): small numbered boards. The current one has a
thick ring, finished ones turn green with a check. A star flies into each one.

**Summary chips**: ✔ word (green), ↺ word with an error count (orange),
dashed for "ยังไม่ตอบ", yellow 💡 for hint steps.

### 7. Icons and emoji

Draw UI icons as inline SVG with `stroke="currentColor"`. Glyphs like ✔ ↺ ▶
are missing from some TV fonts. The template's `IC` object has: `check`,
`retry` (↺), `next` (▶), `cross`, `home`, `full`, `sound`, `mute`. The star is
`starSVG(fill)`.

Emoji are the pictures: word pictures, scenes, shops, rewards and the
cartoon ✋ hand. Rules:
- Store a scene as an array of emoji, one per item. ZWJ sequences such as
  👩‍👧 count as one item, so never split strings by character.
- Add a caption when the emoji alone is ambiguous (🍌 for หยวกกล้วย). Check
  whether the caption reveals the answer.
- Never let an emoji be the *only* carrier of meaning in feedback. That job
  belongs to SVG icons plus text.

### 8. Motion catalogue

One clear animation per event; idle motion stays subtle. All of it is
switched off under `prefers-reduced-motion`.

| Class or function | What it does | Used on |
|---|---|---|
| `in-drop` | bounces up from below (0.55 s, `backwards`) | tiles, cards, shops, stalls, recap cards |
| `in-pop` | scales from 0.6 to 1 | picture frames, basket, start button, bubble |
| `in-rise` | slides up 25% with a fade | sentence box, story lines, demo text |
| `in-swing` | a hanging sign swings in | map title board, Level 1 sign, cover sign |
| `delayStyle(sec)` | inline `animation-delay` to stagger | rows of pieces |
| `bob` (idle) | 6% float | scene emoji, picture emoji, shop emoji, stall goods |
| `sway` (idle) | ±1° on hanging signs | title boards |
| `glow` (idle) | soft ring pulse | the active blank |
| `shake` | wrong-answer wiggle | tile, card, slot, blank |
| `checkin`, `pop` | correct-answer badge and filled slot | big check, slot, progress board |
| `hopword` (`.wave`) | filled words hop one after another | finished sentence |
| `hop` / `runby` | the scene celebrates (page `anim: 'run'` for chases) | scene emoji |
| `stampin` | stamp drops onto the shop card | map |
| `burst(el, n, spread)` | stars and confetti burst from an element | correct answer, page done, basket |
| `confetti(n)` | confetti rains over the whole screen | finish screens |
| `flyStar(from, to, done)` | a star flies to the progress board | Level 1 correct answer |

Order matters in the CSS: entrance and idle classes first, then `.shake`,
then `.removed`. Pressable elements use only `backwards` fill.

### 9. Cover page composition

- Bunting under the awning.
- A big hanging wood sign: the title at 12.6u, with the target letters
  highlighted in the answer colour (in "วัน**ห**นึ่งที่**ต**ลาด" both leading
  consonants are coloured), a subtitle, and a rotated blue badge "ภาษาไทย
  ป.1–3".
- Three stalls with striped awnings, poles, a wooden counter with a label
  (ผักสด / ขนมหวาน / หนังสือ) and bobbing goods. The labels can reuse target
  words.
- A child with a basket (👧🧺) walking along the bottom, behind the button.
- The เริ่มเล่น button at 80.5u with a breathing ring, and a small teacher
  note at the bottom-left: "ครู: แตะ “เต็มจอ” ที่มุมขวาบน ก่อนเริ่มเล่น".

### 10. Giving a new game its own flavour

Keep the system and vary the content:
- **Stalls and goods**: fruit stall for สระ, fish stall for มาตราตัวสะกด, toy
  stall for คำควบกล้ำ.
- **Stall and shop awning colours**: use the existing three pairs, or derive
  a new pair at the same lightness, a strong stripe plus a pale one.
- **Shopkeeper** (👵 in Level 1): any market character with a short speech
  bubble.
- **Rewards**: a market item that matches the shop (🥬, 📚, 🐟, 🍉).
- **Scene backgrounds**: the `bg-*` gradients (sky, market, veg, pink, sun,
  park, book). Add new ones in the same pale style.

Avoid changing the font, the ink and paper contrast, the pressable-card
shape or the zone layout. Those carry the usability.


---

# Reference: ux-patterns

## UX patterns: interaction, feedback, flow, teacher tools

### Contents
1. Screen map
2. Touch input model
3. Answering: active slot, tap, drag
4. Feedback copy and timing
5. Hints
6. Demo screen recipe
7. Level recipes (letter fill, cloze story, future mechanics)
8. Rewards and finish screens
9. Teacher summary
10. Sound design
11. Accessibility and keyboard

---

### 1. Screen map

```
cover ──เริ่มเล่น──► map ──shop──► demo ──เริ่มเลย──► level (n questions or pages)
                      ▲  │                                   │ ไปต่อ after the last one
                      │  └─สรุปผลสำหรับครู─► summary          ▼
                      └──────────กลับแผนที่────────── finish screen / read-aloud page
```
- `หน้าแรก` (teacher corner) always returns to the map. It is hidden on the
  cover and the map. Partial progress is kept.
- Every screen change goes through `setScreen(html, name, status)`. It clears
  timers, cancels any gesture, removes clones and effects, fades in, and
  locks taps for 350 ms so the tap that changed the screen can't also press
  something on the new one.
- A level remembers nothing between visits. Replaying starts a new round in
  the stats.

### 2. Touch input model

All input goes through one gesture adapter (`bindPress`). It uses Pointer
Events and falls back to touch plus mouse events on old browsers.

- **Tap vs drag**: movement under 10 px from the start point is a tap. Big
  panels jitter, so a strict threshold would turn taps into failed drags.
- **Buttons** (`onTap`) fire on release *if the finger is still within
  16 px of the button*, even after moving. The pressed state follows the
  finger. Keyboard `click` events (`e.detail === 0`) also fire, for teachers
  using a remote.
- **One gesture at a time; the newest wins.** A new touch cancels the
  previous gesture (its clone flies home). A palm resting on the glass would
  otherwise block every tap.
- **`busy` flag** while an answer animation runs: pieces ignore presses, but
  teacher buttons still work.
- **Tap locks**: 350 ms after a screen change, and 300 ms when ไปต่อ appears.
- **No hover effects, double-tap or long-press.** The context menu,
  selection, native drag and pinch zoom are all prevented.

### 3. Answering: active slot, tap, drag

- **Active slot**: in multi-blank tasks the first empty blank is active
  (solid blue border, "?" and a glow). Tapping a piece fills the active
  blank. Tapping another empty blank makes it active. After a correct fill,
  the next empty blank (searching forward, then wrapping around) becomes
  active automatically.
- **Drag**: the piece's clone follows the finger at 1.08× scale with a
  shadow, and the original stays behind as a faint ghost. The drop target is
  the nearest empty slot whose rectangle, widened by a margin, contains
  either the clone's centre or the finger point. Margins are 6u around the
  whole sign for a single slot, and 2.5u around each blank in a sentence.
  The target under the finger is highlighted while dragging.
- **Dropping on nothing**: the clone flies home with no penalty and a soft
  "drop" sound.
- **Tap animation**: a tapped piece also flies to the slot (≈ 240 ms), so tap
  and drag look the same: correct pieces land, wrong ones bounce back.
- **Correct**: the slot fills in the answer colour, the piece's place stays
  empty (`visibility:hidden`), a burst plays, and the feedback pill shows the
  word plus its reading guide.
- **Wrong**: the piece flies back (300 ms) and shakes, and the slot shakes.
  In single-answer tasks the piece dims with a ✖ badge and can't be chosen
  again. In multi-answer tasks it stays usable, because it may belong in
  another blank. Errors are recorded against the target word.
- **Any-order groups**: blanks that accept their answers in any order (three
  vegetables in a list) check against the remaining answers of the group.
- **After the last answer**: hide the pieces and the hint button, celebrate,
  then show ไปต่อ ▶ in the pieces' place after about 0.45–0.9 s.

### 4. Feedback copy and timing

Short, kind, concrete Thai. Icon first, one line.

| Moment | Copy (Thai) |
|---|---|
| correct letter | ✔ **หมู** — เติม **ห** สำเร็จ, with "อ่านว่า หฺมู" under the word on the sign |
| correct word | ✔ **หนึ่ง** อ่านว่า **หฺนึ่ง** |
| page complete | ✔ **ใหม่** อ่านว่า **ไหฺม่** · ครบแล้ว! อ่านประโยคพร้อมกันนะ |
| wrong letter | ↺ ดูภาพ แล้วลองอีกครั้ง |
| wrong word | ↺ อ่านประโยคอีกครั้งนะ |
| hint 1, silent ห | 💡 ตัวอักษรนี้นำหน้า แต่ไม่ออกเสียง |
| hint 1, sounded leading letter | 💡 ตัวอักษรนี้ออกเสียงสั้น ๆ มีเสียง อะ |
| hint 1, cloze | 💡 อ่านคำที่ขีดเส้นใต้ แล้วเลือกคำที่เข้ากัน |
| hint 2 | 💡 เอาตัวที่ไม่ใช่ออกไปแล้ว 1 ตัว / เอาบัตรคำที่ไม่ใช่ออกไปแล้ว 1 ใบ |
| level done | ✔ ซ่อมป้ายครบแล้ว! เก่งมาก · 👵 ขอบใจนะ ป้าให้ 🥬 กะหล่ำปลี ใส่ตะกร้า |
| demo line | ลากตัวอักษรไปวางในช่องว่าง หรือแตะตัวอักษรก็ได้ |
| map tip | 👆 แตะร้านเพื่อเริ่มเล่น |

Never say "ผิด" (wrong) to the child. Refer to colours in copy only together
with a shape ("ขีดเส้นใต้", not "สีเหลือง" alone).

### 5. Hints

- One 💡 คำใบ้ button at the bottom-left of zone D, with a badge showing the
  hints left (2, 1, 0). It disables itself when there is nothing more it can
  do.
- **Step 1 teaches.** Level 1: the slot pulses and the group tip appears.
  Cloze: the clue word before the active blank is highlighted and
  underlined. Mark clue words in the data with `[ ]`. If none is marked, the
  nearest earlier clue is used, and failing that the text right before the
  blank. The highlight follows the active blank.
- **Step 2 narrows.** It removes one wrong choice (a random wrong tile, or
  the distractor card). The space stays empty so nothing shifts.
- Record the highest step used per item for the summary.

### 6. Demo screen recipe

Shown once before each level (every time the shop is entered):
- Top: one story line (why we are here) and one instruction in a pill.
- Middle: a sample item made of words outside the lesson list, so no
  answers are revealed (หนู with 🐭 for a letter task, "ฉันเห็น{หนู}ตัวเล็ก" for
  a cloze task).
- Pieces row: a demo copy of the real pieces with `pointer-events:none`.
- A cartoon ✋ hand, positioned below and to the right of the piece so the
  letter stays visible, loops through: fade in (0.3 s) → move onto the piece
  (0.45 s) → grab (scale 0.86) → carry the piece to the slot (1.1 s) → the
  slot fills → fade out → restart after 4 s. The loop runs on `later()`
  timers, so `setScreen` stops it.
- Reduced motion: a still picture with the hand on the piece and the slot
  already filled.
- Big เริ่มเลย ▶ at the bottom.

### 7. Level recipes

**Letter fill ("fix the sign")**: a picture in zA, a wooden sign with the word
in zB with one dashed slot (the 12.5u word fits by width), 3 tiles in zD
(the answer plus 2 distractors from a fixed letter set, shuffled), and a
progress boards strip at the top-right. On a correct answer: big check,
reading guide shown on the sign, star to the progress board. 5 random
questions from the pool.

**Cloze story ("complete the story")**: pages in order. A scene frame in zA,
the sentence box in zB with uniform-width blanks, and the word bank in zD:
the page's answers plus one distractor, all cards in one colour. Sentence
markup: `{word}` is a blank, `[clue]` is the hint word for the next blank,
and `anyOrder: true` makes a list of blanks interchangeable. On page
complete: scene celebration (`hop`, or `run` for chases), word wave, burst,
fanfare, then ไปต่อ. The final page shows the **whole story** with the
filled words highlighted, for choral reading.

**Future mechanics** (each becomes a new shop):
- *Word train (รถไฟส่งคำ)*: sort word cards into 2–3 wagons by rule (silent ห
  vs sounded leading letter). The wagons are drop targets in zB, the active
  wagon is the tap target, and a tap on a wagon selects it.
- *Reading bridge (สะพานคำอ่าน)*: match a word to its reading guide. The
  planks are reading cards, and a tap or drag puts the matching plank on the
  bridge.
- *Picture hunt*: a market scene with tappable items. Keep the targets in
  the lower 60%, or give a picture list in zD whose items map onto the scene.

Reuse `makeDraggable`, the active-slot model, `feedback`, hints, stats and
the finish flow for all of them.

### 8. Rewards and finish screens

- **No points or stars for children to compare.** The rewards are story
  progress and market items.
- The first completion of a shop puts its reward item in the basket on the
  map. On return, the item flies from the shop card into the basket
  (whoosh), lands (coin sound plus a burst), the basket label changes to
  "✔ ได้ 🥬 กะหล่ำปลี แล้ว!", and then the stamp drops onto the shop card
  (stamp sound). Replays just say they finished again.
- **Finish screen** (letter levels): a title with ✔, the shopkeeper's thanks
  and reward line, recap cards for every item (picture, word with the
  answer highlighted, reading guide), confetti and a fanfare, then
  กลับแผนที่.
- **Read-aloud page** (story levels): the whole text with highlighted
  answers, zebra-striped lines, the teacher note "ครูให้นักเรียนอ่านออกเสียง
  พร้อมกัน", confetti, and กลับแผนที่.

### 9. Teacher summary

Data model (kept in memory, saved to `localStorage` when possible):
```js
{ v:1,
  done:   { signs:true, story:false },            // stamps and basket
  rounds: { l1:2, l2:1 },                         // times each level was started
  l1: { finished:true, total:5, items:[ {word, wrong, hint, firstTry, done} ] },   // latest round
  l2: { finished:false, total:20, pages:[ {page, hint, done, blanks:[ {word, wrong, firstTry, done} ]} ] },
  wrong:  { 'ขนม': { l1:2, l2:1 } } }             // cumulative, for "คำที่ควรทบทวน"
```
- Record a wrong attempt the moment it happens. For blanks, add the attempts
  to `wrong[word]` when the blank is finally filled, so any-order groups
  credit the word actually placed.
- **One panel per skill** ("ทักษะ: เติมตัวอักษรนำ", "ทักษะ: ใช้คำในประโยค").
  Each has: first-try score with a bar ("4 / 5 ข้อ ตอบถูกตั้งแต่ครั้งแรก"),
  latest round and total rounds ("(ยังเล่นไม่จบ)" if unfinished), per-item
  chips (✔ / ↺ ×n / ยังไม่ตอบ), hint chips with their step, and words to
  review with readings, sorted by count. Never only one total.
- A note on whether results are saved on this device or will be lost when
  the page closes.
- เล่นใหม่ทั้งหมด uses a two-tap confirm: the first tap changes the label to
  "แตะอีกครั้งเพื่อลบผลทั้งหมด" for 4 s. Browser `confirm()` dialogs are
  avoided because they look broken on TVs and are blocked in some frames.
- The panels fit their text to the panel (min 2.2u) and both rows and
  height are measured.

### 10. Sound design

Synthesized with Web Audio, with no audio files and **no speech** (the game
must not pretend to model pronunciation; the teacher does that).

| Event | Sound |
|---|---|
| any button | `tap`: short soft pop |
| piece lifted (drag starts) | `pick` |
| dropped on nothing | `drop` |
| correct | `correct`: C–E–G–C arpeggio with a sparkle |
| wrong | `wrong`: two soft falling notes, never a buzzer |
| hint step | `hint`: twinkle |
| star reaches progress | `star` |
| ไปต่อ | `next`: page-turn whoosh plus pop |
| เริ่มเล่น / เริ่มเลย | `start`: rising arpeggio |
| page complete | `fanfare` |
| finish or read-aloud page | `tada` |
| reward flies / lands / stamp | `whoosh` / `coin` / `stamp` |

- Master volume around 0.6, individual sounds 0.07–0.3, triangle or sine
  waves for warmth, square waves only very quietly.
- 🔊 เสียง: เปิด/ปิด in the teacher corner, remembered in storage. Audio
  unlocks on the first pointerdown, keydown or touchstart. With no Web Audio,
  `Sound.play` silently does nothing.
- **If the brief says no sound**, remove the `Sound` module, the toggle and
  every `Sound.play` call (use `onTap(..., false)`), and state in the report
  that the code contains no audio.

### 11. Accessibility and keyboard

- The feedback pill has `role="status" aria-live="polite"`. Shops, tiles and
  cards are `<button>` elements with Thai `aria-label`s, and blanks have
  `role="button"`.
- Keyboard and remote: Enter or Space on a focused button or piece acts as a
  tap.
- Reduced motion: no bursts, confetti, flying star or hand loop. Animations
  last 1 ms and transitions are off.


---

# Reference: thai-text

## Thai text: blanks, marks, readings and copy

Thai stacks vowels and tone marks above and below consonants and has no
spaces between words. Most visual bugs in these games come from that. Follow
these rules wherever text is split, boxed or fitted.

### 1. Splitting a word around a blank

Render a missing-letter word as three pieces: `before` + `<span class="slot">` + `after`.

- The text **after** a blank must begin with a consonant or a leading vowel
  (เ แ โ ใ ไ). It must never begin with a combining mark:
  ั ิ ี ึ ื ุ ู ็ ่ ้ ๊ ๋ ์ ํ ำ ฺ. A span that starts with a combining mark
  renders a dotted circle (◌).
- The missing letter should be a base consonant that carries no marks of its
  own. That holds for all leading-consonant words (ห in หมู, กะ_ล่ำปลี,
  เ_ลือง). If a future task needs to blank a consonant that *carries* a vowel
  or tone, blank the whole cluster (consonant + marks) as one piece instead.
- Store the pattern in the data (`blank: 'กะ_ล่ำปลี'`) and derive the answer:
  `answer = word.charAt(blank.indexOf('_'))`, then check that
  `before + answer + after === word`. Skip rows that fail instead of showing
  a broken sign. Thai characters are single UTF-16 units, so `charAt` is
  safe.
- Leading vowels on their own (เ in เ_ลือง) render fine in a separate span.

### 2. The slot box

```css
.slot{display:inline-block;vertical-align:baseline;min-width:.8em;padding:0 .07em;line-height:1.12;
      border:.05em dashed var(--wood);border-radius:.14em;background:#fff;}
.slot .ch{visibility:hidden;}          /* placeholder "ก" sets width and baseline */
.slot.filled{border-style:solid;border-color:var(--hi);background:var(--hi-bg);}
.slot.filled .ch{visibility:visible;color:var(--hi);}
```
An invisible "ก" keeps the empty box one consonant wide and on the text
baseline. It was checked with Mali and with a fallback Thai font. Inside a
word, the box sits slightly high, because its height includes the space for
upper marks. That is acceptable.

### 3. Blanks for whole words (cloze)

- Use an inline-block with a **uniform** `min-width` (3.1em) when empty, so
  the blank length doesn't hint at the answer. It grows when filled.
- `line-height: 1.45` inside the blank and `1.95` on the sentence, so boxes
  on consecutive lines don't touch the upper marks of the line below.
- Mark the hint clue in the data with `[ ]`, because Thai has no spaces to
  find "the word before the blank" automatically:
  `'เช้า[วัน]{หนึ่ง} ฉัน[ล้าง]{หน้า} แล้วใส่[เสื้อตัว]{ใหม่}'`.
  A clue belongs to the next blank. A blank with no clue of its own uses the
  nearest earlier clue.
- Keep the original spaces between phrases. They are part of Thai
  punctuation.

### 4. Line height and clipping

- **Never put `overflow:hidden` on a line of Thai** unless it has padding.
  It cuts off ู ุ below the line and stacked marks such as ้ above ื
  (เสื้อ, ซื้อ). Text measured for width can stay `overflow: visible`,
  because `scrollWidth` still reports the overflow.
- Single line: line-height ≥ 1.42. Multi-line reading text: ≥ 1.6, or the
  stacked marks of one line collide with the line above. The story page
  needed 1.62.
- Add bottom padding to signs and boxes so lower vowels stay inside the
  frame.
- Check stacked marks by zooming into a screenshot (crop and scale it). At
  full-screen size they look fine even when clipped.

### 5. Fitting text

`fitText(el, maxU, minU, axis)` lowers the font size in 0.2u steps until
the element stops overflowing (`'h'`, `'w'` or `'hw'`). Requirements:
- The element needs a fixed size, or a max-height or width, so overflow can
  be measured.
- Transitions are disabled and animations paused while measuring (done
  inside `fitText`).
- Run it again after `document.fonts.ready` and on resize (`currentFit`).
- Choose `minU` to respect the size floors (sentences 6u, words 10u). If
  teacher-added content would need less, let it go lower rather than
  overflow, and mention it.

### 6. Reading guides (คำอ่าน)

The notation follows Thai school books:
- Phinthu (ฺ) under a silent leading letter: หมู → **หฺมู**, ใหม่ → **ไหฺม่**,
  อยาก → **หฺยาก**.
- A hyphen between syllables: กะหล่ำปลี → **กะ-หฺล่ำ-ปฺลี**, ขนม → **ขะ-หฺนม**,
  ตลาด → **ตะ-หฺลาด**, สนิทสนม → **สะ-หฺนิด-สะ-หฺนม**.
- Show the reading **after** a correct answer ("อ่านว่า …"), never before,
  so it doesn't give the answer away.
- Readings come from the data (`read` field). Don't generate them, because
  they are easy to get wrong.

### 7. Groups and hints for leading consonants (อักษรนำ)

| Group | Example | Hint 1 that is true for the whole group |
|---|---|---|
| ห นำ (silent ห) | หมู หญิง ใหม่ | ตัวอักษรนี้นำหน้า แต่ไม่ออกเสียง |
| อ นำ ย (silent อ) | อย่าง อยาก | ตัวอักษรนี้นำหน้า ย แต่ไม่ออกเสียง |
| high-class consonant leading a single low-class one | ขนม เสมอ | ตัวอักษรนี้ออกเสียงสั้น ๆ มีเสียง อะ |
| mid-class consonant leading a single low-class one | ตลาด อร่อย | ตัวอักษรนี้ออกเสียงสั้น ๆ มีเสียง อะ |

Write hints per group, with an optional per-word `tip` override. Check every
hint against every word it appears with.

### 8. Line breaking and fonts

- Modern browsers break Thai lines with a dictionary. Old ones may only break
  at spaces, so add `overflow-wrap: break-word` as a safety net. Splitting
  sentences into spans at blanks also creates safe break points.
- Mali (Google Fonts, `display=swap`) with fallbacks: Itim, Leelawadee UI,
  Thonburi, Noto Sans Thai, Sarabun, Tahoma. Test once with the font blocked.
- Check that the font has the phinthu (ฺ). Mali and the listed fallbacks do.

### 9. Copy for Grade 1–3

- Short sentences of 8 words or fewer, everyday words, a friendly นะ, and
  no grammar jargon in children's text (use "ตัวอักษรนี้นำหน้า", not
  "อักษรนำ"). Teacher text (summary, notes) may use the terms.
- Name the action the child does ("ลาก… หรือแตะ…ก็ได้").
- The shopkeeper and story characters speak in first person to make it a
  story ("ป้ายหลุดไป 1 ตัว ช่วยเติมหน่อยนะ").


---

# Reference: tv-compat

## Smart-TV compatibility and testing

Classroom smart TVs and interactive boards often run old Chromium or WebKit
browsers that never update. Write for them and test the degraded paths.

### 1. JavaScript: ES5 only

Allowed: `var`, `function`, ES5 array methods (`forEach`, `map`, `filter`,
`indexOf`), `JSON`, `Object.keys`, `Object.defineProperty`,
`requestAnimationFrame`, `classList` without the second `toggle` argument
(the template uses its own `addCls/rmCls/setCls` helpers anyway).

Avoid, with the replacement to use:

| Avoid | Use |
|---|---|
| arrow functions, template literals, `let`/`const`, `class`, destructuring, default params, spread | `function`, string concatenation, `var` |
| `?.`, `??` | explicit checks: `a && a.b`, `x != null ? x : y` |
| `Array.from`, `.includes`, `.find`, `Object.assign` | loops, `indexOf` |
| `NodeList.forEach` | `for` loop over `querySelectorAll` |
| `element.remove()`, `.closest()` | `parentNode.removeChild`, walk up manually |
| `async`/`await`, unguarded `Promise` | callbacks and `setTimeout`. Call `.then` only after checking it exists (`document.fonts.ready`, fullscreen, `audio.resume`) and catch rejections with `.then(null, fn)` |

Check with `scripts/check_static.py`, which parses the script as strict
ES5 when Node plus acorn is available.

### 2. CSS

Avoid: flex `gap`, `inset`, the `aspect-ratio` property, `:is()`, `:where()`,
`:has()`, `light-dark()`, `min()`/`max()`/`clamp()` in values, CSS nesting,
`@container`, and `color-mix()`.

Fine: flexbox with margins, `calc()` with custom properties (Chrome 49+),
`vh`/`vw`, transforms, `@keyframes`, `repeating-linear-gradient`,
`radial-gradient` with length stops, and media queries on `aspect-ratio` and
`orientation`.

Put `var()` only in normal declarations. Keyframes use `%` or `em` instead
of u units, because custom properties inside `@keyframes` are unreliable on
old engines.

### 3. Input

- `if (window.PointerEvent)` use pointer events, else touch events
  (`passive:false` when supported, detected with the `Object.defineProperty`
  trick) plus mouse events. Call `preventDefault` on touchstart so no
  emulated mouse events follow.
- Set `touch-action:none` on body and on pieces. Prevent `touchmove`,
  `gesturestart`, `contextmenu`, `dragstart` and `selectstart` globally.
- Use `user-scalable=no` in the viewport meta (many TVs ignore it, but it
  costs nothing).

### 4. Storage, fullscreen, audio

- **Storage**: wrap *every* access in try/catch, including reading
  `window.localStorage` itself, which throws in sandboxed frames. Validate
  the loaded object's shape and version, fall back to fresh stats, and show
  the teacher whether saving works.
- **Fullscreen**: `requestFullscreen || webkitRequestFullscreen ||
  webkitRequestFullScreen || msRequestFullscreen`, called inside the tap.
  Ignore promise rejections, hide the button when none exists, and update
  its label on `fullscreenchange`/`webkitfullscreenchange`.
- **Audio**: `window.AudioContext || window.webkitAudioContext`. Create or
  resume it in the first user gesture, and never before (Chrome logs a
  warning). Wrap every play in try/catch. No Web Audio means silence and
  nothing else.

### 5. The 16:9 stage on real screens

| Screen | What happens |
|---|---|
| TV in fullscreen (1920×1080, 3840×2160) | the stage fills exactly |
| TV browser with toolbar (e.g. 1920×950), wider than 16:9 | the stage fills the height, and the awning and background continue to the sides |
| laptop 16:10 (1440×900), 4:3 (1024×768) | the stage fills the width at the top, with a wooden counter below |
| portrait panel or phone | the stage sits at the top, with the counter and the "หมุนจอเป็นแนวนอน" hint below |

### 6. Test matrix

Run all of these before delivering; `scripts/check_layout.js` covers most of them automatically:

1. 1920×1080 with mouse taps through the whole game, then again with drags.
2. Touch input (Playwright `hasTouch`, CDP `Input.dispatchTouchEvent` for
   drags).
3. Pointer Events removed (`window.PointerEvent = undefined`), using touch.
4. `localStorage` throwing (an init script that redefines the getter to
   throw).
5. `prefers-reduced-motion: reduce`.
6. Web Audio missing (`window.AudioContext = undefined`).
7. Google Fonts blocked (fallback font).
8. Viewports 1366×768, 1440×900, 1024×768, 3840×2160, 1920×950 and
   820×1000.
9. A static check, and an ES5 parse.

For every run, check: no console errors (a blocked font request is
expected), controls at or below 40%, minimum sizes met, and screenshots that
look right. Wait about 1 s after a screen change before measuring. Wait for
`#nextWrap.show` instead of using fixed sleeps.

Playwright tips: Chromium may be pre-installed, so try `require('playwright')`
before installing anything. Use `deviceScaleFactor: 1` for checks. To test
with the real font offline, download the Mali CSS and woff2 files once and
serve them with `page.route` (the example play-through accepts `--fonts
<dir>`).

### 7. Hosted preview pages (for example Claude Artifacts)

Hosts that wrap your HTML in their own page skeleton need the game's
`<!DOCTYPE>`, `<html>`, `<head>` and `<body>` stripped (keep the `<title>`,
font `<link>`s, `<style>` and body content). Drop the viewport meta, because
the host adds its own. Google Fonts and
inline scripts are allowed. Fullscreen may be refused inside the preview
frame. That is fine, since the button handles the rejection.


---

# Reference: template-map

## Template map: `assets/game-template.html`

The template is the finished วันหนึ่งที่ตลาด game. It is one HTML file: a
`<style>` block, then one `<script>` IIFE in numbered sections with Thai
headers ("ส่วนที่ n"). Search for those headers to jump to a section.

### Contents
1. What to keep, adapt or replace
2. Data you edit (section 1)
3. Helper API (sections 2–5)
4. Adding a new shop (step by step)
5. Making a brand-new game from the template
6. Checklist after editing

---

### 1. Keep / adapt / replace

| Part | Search for | Action |
|---|---|---|
| CSS: stage, awning, floor, buttons, textures, tiles, cards, effects, entrance and idle motion, feedback, keyframes, reduced motion | `/* ---------- เวที 16:9`, `ปุ่มกดแบบนูน`, `พื้นผิว`, `เอฟเฟกต์ดาว`, `เข้าฉาก`, `ภาพเคลื่อนไหว` | **keep** |
| CSS: screen-specific blocks (sign, scene and sentence, map, demo, finish, story, summary, cover) | `ป้าย + ช่องว่าง`, `ฉาก + ประโยค`, `หน้าแรก: แผนที่ตลาด`, `หน้าสาธิต`, `จบด่าน 1`, `นิทานของเรา`, `สรุปผลสำหรับครู`, `หน้าปก` | adapt and reuse; add new blocks with prefixed class names |
| ส่วนที่ 1: data (`WORDS`, `LETTER_CHOICES`, `GROUP_TIPS`, `LEVEL1_QUESTIONS`, `STORY`, `SHOPS`) | `ส่วนที่ 1` | **replace** with the new content |
| ส่วนที่ 2: utilities (`$`, `esc`, `shuffle`, class helpers, timers, `D()`, `fitText`, `awningTile`, `IC` icons) | `ส่วนที่ 2` | keep |
| ส่วนที่ 3: stats storage | `ส่วนที่ 3 :` | keep the mechanism; change the shape of `stats.l1/l2` if the levels change, and bump `STORE_KEY` for a new game |
| ส่วนที่ 3.5: `Sound` | `ส่วนที่ 3.5` | keep (remove it if the brief says no sound) |
| ส่วนที่ 4: touch (`bindPress`, `onTap`, `makeDraggable`, clones, flights, `pickTarget`) | `ส่วนที่ 4 :` | keep |
| ส่วนที่ 4.5: effects (`burst`, `confetti`, `flyStar`, `delayStyle`) | `ส่วนที่ 4.5` | keep |
| ส่วนที่ 5: shell, `setScreen`, `feedback`, fullscreen, sound toggle | `ส่วนที่ 5 :` | keep |
| ส่วนที่ 5.5: cover | `ส่วนที่ 5.5` | adapt the title, highlighted letters, stalls and labels |
| ส่วนที่ 6: map, reward animation | `ส่วนที่ 6` | keep; title text from the new game |
| ส่วนที่ 7: demo | `ส่วนที่ 7` | keep; supports `kind: 'letter'` and `'word'`, add a kind for a new mechanic |
| ส่วนที่ 8: Level 1 letter fill | `ส่วนที่ 8` | reuse as is for missing-letter tasks, or as the model for a new level |
| ส่วนที่ 9: Level 2 cloze story, read-aloud page | `ส่วนที่ 9` | reuse for any fill-the-sentence task |
| ส่วนที่ 10: teacher summary | `ส่วนที่ 10` | keep; add one panel per new skill |
| Start-up (`buildShell(); showCover();`) | end of the script | keep |

### 2. Data you edit (ส่วนที่ 1)

```js
var WORDS = [   // one array for every word in the game
  { word:'หมู', read:'หฺมู', group:'A', pic:'🐷', blank:'_มู' },          // in the Level 1 pool because it has `blank`
  { word:'หยวก', read:'หฺยวก', group:'A', pic:'🍌', blank:'_ยวก', caption:'หยวกกล้วย' },
  { word:'หน้า', read:'หฺน้า', group:'A' },                                // story only
  // tip:'…' overrides the group hint for one word
];
var LETTER_CHOICES = ['ห','อ','ส','ข','ต'];   // tiles = the answer + 2 random others from here
var GROUP_TIPS = { A:'…', B:'…', C:'…', D:'…' };
var LEVEL1_QUESTIONS = 5;
var STORY = [
  { scene:['☀️','🏠','👧'], bg:'sky', text:'เช้า[วัน]{หนึ่ง} ฉัน[ล้าง]{หน้า} แล้วใส่[เสื้อตัว]{ใหม่}', extra:'หมู' },
  { scene:['🥬','🎋','🍌'], bg:'veg', anyOrder:true, text:'[ร้านผักมี]{กะหล่ำปลี} {หน่อไม้} และ{หยวก}', extra:'ใหญ่' },
  { scene:['🐈','💨','🐕'], bg:'park', anim:'run', text:'[แมวตัว]{ใหญ่}[วิ่ง]{หนี}สุนัข', extra:'หวาน' }
];
var SHOPS = [
  { id:'signs', icon:'🪧', name:'ร้านซ่อมป้าย', level:'ด่าน 1', skill:'เติมตัวอักษรนำ', theme:'s1',
    reward:{ icon:'🥬', name:'กะหล่ำปลี' },
    demo:{ kind:'letter', story:'…', how:'ลากตัวอักษรไปวางในช่องว่าง หรือแตะตัวอักษรก็ได้',
           pic:'🐭', blank:'_นู', tiles:['ส','ห','ต'], answer:'ห' },
    start:function(){ startLevel1(); } },
  { id:'story', /* … */ demo:{ kind:'word', /* … */ before:'ฉันเห็น', after:'ตัวเล็ก', cards:['ไก่','หนู'], answer:'หนู' },
    start:function(){ startLevel2(); } }
];
```
Every field has a Thai comment in the template. Keep them, because teachers
edit these arrays.

### 3. Helper API

**Screens and timing**
- `setScreen(html, name, statusHtml)`: replaces `#screen`; clears timers,
  gestures, clones and effects; fades in; tap lock of 350 ms; hides หน้าแรก on
  `'cover'` and `'home'`. Then set `currentFit = function(){…}` and call it.
- `later(fn, ms)`: a `setTimeout` that `setScreen` cancels. Use it for
  everything that belongs to the screen.
- `D(ms)`: returns 1 under reduced motion. Wrap motion durations in it, but
  not sound timings.
- `lockTaps(ms)`: ignore taps for a while (used when ไปต่อ appears).
- `busy`: set it while an answer animation runs.

**Touch**
- `onTap(el, fn, snd)`: button behaviour. `snd` is a sound name, defaults to
  `'tap'`; `false` means silent.
- `makeDraggable(el, { canUse(el), tap(el), drop(el, clone, target), targets() })`:
  tap-or-drag piece. `targets()` returns
  `[{ el, zone?, margin(u), ...data }]`. The `drop` callback receives the
  chosen target object.
- `makeClone(el)`, `flyTo(clone, x, y, ms, cb)`, `deltaTo(clone, targetEl)`,
  `flyHome(el, clone)`: the flight animations used by every attempt.
- `removeChoice(el)`: hint step 2; pops the piece out and keeps its space.

**Feedback and effects**
- `feedback('ok' | 're' | 'tip', html)`: the pill in zone C with its icon,
  fitted to one line.
- `restartAnim(el, cls)`: replays a CSS animation class (`'shake'`,
  `'hinted'`, `'wave'`).
- `burst(el, n, spread)`, `confetti(n)`, `flyStar(fromEl, toEl, done)`,
  `delayStyle(sec)` (returns ` style="animation-delay:…"`).
- `Sound.play(name)`: `tap pick drop correct wrong hint star next start
  fanfare tada whoosh coin stamp`.
- `fitText(el, maxU, minU, 'h' | 'w' | 'hw')`.
- `IC.check / retry / next / cross / home / full / sound / mute`,
  `starSVG(fill)`, `esc(text)`, `shuffle(array)`.

**Stats**
- `stats` (the object described in ux-patterns §9), `saveStats()`,
  `addWrong(word, levelKey, n)`, `freshStats()`.
- `pendingReward = shopId` before returning to the map triggers the basket
  and stamp animation.

### 4. Adding a new shop (step by step)

1. **Data**: add the content array near the others, with Thai field comments.
2. **Shop entry**: push `{ id, icon, name, level, skill, theme, reward, demo, start }`
   to `SHOPS`. Give it a new `theme` class for its card awning colours. The
   map fits 2 cards at the current size (62u wide plus 7u margins each).
   For 3 cards set `.shop` to about 50u wide with 3u margins and scale the
   emoji and name down a little. For 4 or more, use two rows or a scrolling
   street. Keep cards at least 12u tall and in the lower 60%.
3. **Demo**: reuse `kind:'letter'` or `'word'`, or add a branch in
   `showDemo` that builds a sample plus a `mover` piece and a `dSlot`
   target. The hand loop only needs those two ids.
4. **Level code**, modelled on ส่วนที่ 8:
```js
var L3 = null;
function startLevel3() {
  L3 = { qs: shuffle(POOL).slice(0, 5), i: 0 };
  stats.rounds.l3 = (stats.rounds.l3 || 0) + 1;
  stats.l3 = { finished: false, total: L3.qs.length, items: [] };
  saveStats(); renderL3();
}
function renderL3() {
  var q = L3.qs[L3.i];
  L3.rec = { word: q.word, wrong: 0, hint: 0, firstTry: false, done: false };
  stats.l3.items[L3.i] = L3.rec; saveStats();
  var html = '<div class="zone zA center">…picture…</div>' +
    '<div class="zone zB center">…targets…</div>' +
    '<div class="zone zC center"><div class="fb" id="fb" role="status" aria-live="polite"></div></div>' +
    '<div class="zone zD">' +
      '<button class="btn btn-hint in-drop"' + delayStyle(0.3) + ' id="btnHint">💡 คำใบ้<span class="cnt" id="hintCnt">2</span></button>' +
      '<div class="tiles" id="pieces">…pieces with class in-drop…</div>' +
      '<div class="nextwrap" id="nextWrap"><button class="btn btn-next btn-go" id="btnNext">ไปต่อ ' + IC.next + '</button></div>' +
    '</div>';
  setScreen(html, 'l3', '🚂 ชื่อร้าน<span class="sep">·</span>ข้อ ' + (L3.i + 1) + ' / ' + L3.qs.length);
  // makeDraggable(...) for each piece; onTap($('btnHint'), l3Hint, false); onTap($('btnNext'), l3Next, 'next');
}
// l3Attempt(piece, clone, target): busy = true; fly to the target; correct → l3Solved(); wrong → wrong++, addWrong, feedback('re', …), Sound.play('wrong'), fly back, shake
// l3Solved(): rec.done = true, rec.firstTry = rec.wrong === 0, saveStats(); feedback('ok', word + reading); Sound.play('correct'); burst(...);
//            hide the pieces and hint; later(function(){ lockTaps(300); addCls($('nextWrap'), 'show'); }, D(450));
// l3Next(): next question, or stats.l3.finished = true; first completion → stats.done[id] = true, pendingReward = id; the finish screen
```
5. **Finish screen**: copy `showL1Done` (recap, reward line, confetti,
   `tada`).
6. **Summary**: add `panelL3()` modelled on `panelL1()`, and give `.sum` a
   third column (or a second row) when there are 3 skills. Keep one panel
   per skill.
7. **Stats loading**: `loadStats()` copies only the known keys, so add
   `l3` there and in `freshStats()`.
8. **Copy**: the demo story line, instruction, hint tips and feedback lines
   in the style of ux-patterns §4.

### 5. Making a brand-new game from the template

- Change the `<title>`, the cover title (highlight the target letters), the
  map title board and subtitle, `STORE_KEY` (so old results are not mixed
  in), the shops, the rewards and the stall labels.
- Replace `WORDS`, `GROUP_TIPS` and the story with the new skill's content,
  or delete the levels you don't need: remove their shop entries, functions
  and summary panels. Then search for leftover references such as `L1`,
  `L2` and `panelL2`.
- Keep the engine sections untouched unless you are fixing a real bug, and
  if you fix one, consider copying the fix back into this skill's template.

### 6. Checklist after editing

- `python3 scripts/check_static.py <file>` passes.
- `node scripts/check_layout.js <file>` reports no FAIL lines and no errors.
- Your play-through (modelled on `scripts/playthrough_example.js`) completes
  every level with taps, again with drags, and in touch mode.
- Screenshots reviewed: cover, each level's question, correct and wrong
  states, the finish page and the summary. Zoom in on any Thai text with
  stacked marks.
- Every new data field has a Thai comment, and the report to the user lists
  the decisions you made.
